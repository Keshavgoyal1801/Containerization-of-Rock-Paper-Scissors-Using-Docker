let compCount = 0;
let youCount = 0;
let cor = false;
let draw = false;
function randomGenerator() {
  let gen = Math.floor(Math.random() * 3);
  return gen;
}
function comparisons(num1, num2) {
  if (num1 === num2) {
    draw = true;
    return "It's Draw";
  } else if (num1 === 0) {
    if (num2 === 1) {
      youCount++;
      cor = true;
      return "You Win. Paper beats Rock";
    } else {
      compCount++;
      cor = false;
      return "You Lose. Scissor beats Paper";
    }
  } else if (num1 == 1) {
    if (num2 === 2) {
      youCount++;
      cor = true;
      return "You Win. Rock beats Scissor";
    } else {
      compCount++;
      cor = false;
      return "You Lose. Paper beats Rock";
    }
  } else {
    if (num2 === 0) {
      youCount++;
      cor = true;
      return "You Win. Scissor beats Paper";
    } else {
      compCount++;
      cor = false;
      return "You Lose. Rock beats Scissor";
    }
  }
}
for (let i = 0; i < document.querySelectorAll("img").length; i++) {
  let elem = document.querySelectorAll("img")[i];
  elem.onclick = () => {
    let gent = randomGenerator(); //also inside the click function as we generate number after the click takes place so no point in keeping it outside as no number needs to be generate outside
    let res = comparisons(i, gent);
    document.getElementsByClassName("value")[0].textContent = youCount; //both the counts should be included in the onclick function because we are trying to change when the click happens not outside cause then their is no event
    document.getElementsByClassName("value")[1].textContent = compCount;
    document.querySelector(".result").textContent = res;
    if (draw === true) {
      document.querySelector(".result").style.background = "#ff9898";
    } else if (cor === true) {
      document.querySelector(".result").style.background = "green";
      document.querySelector(".result").style.opacity = "0.6";
    } else {
      document.querySelector(".result").style.background = "red";
      document.querySelector(".result").style.opacity = "0.7";
    }
    draw = false; //reset the values of draw for the next game for both cor and draw
    cor = false;
  };
}
